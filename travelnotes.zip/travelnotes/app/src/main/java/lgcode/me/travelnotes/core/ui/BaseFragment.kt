package lgcode.me.travelnotes.core.ui

class BaseFragment: Fragment {
}