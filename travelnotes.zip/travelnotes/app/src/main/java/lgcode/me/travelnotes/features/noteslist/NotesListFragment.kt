package lgcode.me.travelnotes.features.noteslist

class NotesListFragment  {
}