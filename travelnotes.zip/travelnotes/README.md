# TravelNotes
Boilerplate code to bootstrap a MVVM Clean Architecture android app.

# The App
The app iself has a couple of features, as it's intended to use on the road, will provide basic information from your current location(weather initially) and allow to create notes and add some cool pictures from the places you explored.
